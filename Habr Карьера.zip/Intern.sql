--1. Организация данных в Notion

drop table companies;

create table companies 
(name text,
 category text,
 address text,
 phone text,
 url text,
 rating float);
 
insert into companies (name, category, address, phone, url, rating)
values ('Рога и копыта', 'Отели', 'Москва', '174', 'https://roga.com', 4.67),
('Ромашка', 'Развлечение', 'Орел', '123', 'https://flower.com', 4.87),
('Чилдренгартен', 'Отели', 'Москва', '321', 'https://hotel.com', 4.8),
('Мясо и рыба', 'Рестораны', 'Москва', '236', 'https://mett.com', 5),
('Азимут', 'Рестораны', 'Казань', '235', 'https://azimut.com', 3.27),
('Рога', 'Отели', 'Орел', '88005553535', 'https://roga.com', 4.6),
('Копыта', 'Рестораны', 'Казань', '88005553535', 'https://roga.com', 4.12),
('Мамалыга', 'Развлечение', 'Липецк', '88005553535', 'https://roga.com', 4.54),
('Редиссон', 'Отели', 'Санкт-Петербург', '88005553535', 'https://roga.com', 4.09),
('Бистро', 'Рестораны', 'Воронеж', '88005553535', 'https://roga.com', 3.67),
('7 колец', 'Развлечения', 'Воронеж', '88005553535', 'https://roga.com', 4.65),
('Салон', 'Отели', 'Москва', '88005553535', 'https://roga.com', 4.37)

select *
from companies 
order by category;

select * 
from companies 
order by rating desc;

--. Анализ данных с использованием SQL:
select * 
from companies 
where rating > 4;

select category, count(1)
from companies 
group by 1
order by 1;

select *
from companies
order by rating desc
limit 1;

--Шаблон базы данных в Notion:

select *
from companies 
where rating > 4 and category = 'Отели'
















