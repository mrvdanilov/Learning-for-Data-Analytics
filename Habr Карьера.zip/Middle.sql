drop table users;

drop table transactions;

drop table ab_groups;

create table users 
(user_id int,
region text,
registration_date date);

create table transactions 
(transaction_id int,
user_id int,
transaction_date date,
amount int,
'group' text);

create table ab_groups 
(user_id int,
'group' text);

delete from transactions 
where transaction_id is null;

delete from users 
where user_id is null;

delete from ab_groups 
where USER_id is null;

select * from ab_groups;

select * from users;

select * from transactions;

/*
Подготовьте SQL-запрос для расчёта:
Среднего чеĸа для ĸаждой группы.
Общего объёма продаж для ĸаждой группы.
Количества униĸальных пользователей в ĸаждой группе.
 */

with tab as (
select t."group" , 
avg(t.amount) as avg_sm, 
sum(t.amount) as sm, 
count(distinct t.user_id) as uniq_cnt,
count(1) as cnt,
stdev(t.amount) as st_dev
from users u 
join transactions t 
on u.user_id = t.user_id 
group by "group" 
)
select *,
(avg_sm - lead(avg_sm) over(order by 'group'))/(st_dev / sqrt(cnt)) as t_test
from tab 

--t крит для 25000 значений = 1,96 (помощь гугла)

-- выводы статистически значимы 


--Для jupiter Notebook
select *
from users u 
join transactions t 
on u.user_id = t.user_id 