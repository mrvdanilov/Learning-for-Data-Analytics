drop table sales;

create table sales 
(order_id int,
customer_id int,
region text,
product text,
sales_amount int,
transaction_date date,
quantity int
)

select *
from sales;

--Объём продаж по продуĸтам за ĸаждый месяц.
select date(transaction_date, 'start of month'),
product, sum(sales_amount)
from sales 
group by 1, 2;

--Темпы роста продаж по продуĸтам за последние 3 месяца.
--ТОП-3 продуĸта с наибольшим ростом.
with tab as (
select date(transaction_date, 'start of month') as mnt,
product, sum(sales_amount) as sm
from sales 
group by 1, 2
)
select 
product, 
lead(mnt) over (partition by product order by mnt) as growth_mnt,
mnt,
sm, 
lead(cast(sm as float)) over (partition by product order by mnt) as growth_sm,
(lead(cast(sm as float)) over (partition by product order by mnt) - sm) / sm - 1 as growth_temp
from tab 
order by 6 desc nulls last
limit 3
;

