export default {
  testSequencer: '<rootDir>/CustomSequencer.cjs',
  modulePathIgnorePatterns: [
    '<rootDir>/code/',
    '<rootDir>/__tests__/helpers/',
  ],
  testEnvironment: './CustomEnvironment.cjs',
};
