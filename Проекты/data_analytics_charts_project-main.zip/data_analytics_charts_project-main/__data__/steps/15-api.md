## Запросы к API

Ранее мы работали со статичными данными в файлах. Теперь поработает с данными, которые получаем в реальном времени по сети.

### Описание API

У API есть два маршрута со следующими параметрами:

* Запрос на данные по посещениям от даты `START` до даты `END`:

    ```bash
    /visits?begin=START&end=END
    ```

* Запрос на данные по регистрациям c даты `START` по дату `END`:

    ```bash
    /registrations&begin=START&end=END
    ```

Формат даты должен быть вида `YYYY-MM-DD`, например `2023-04-23`

---

Запрос по пути `/visits?begin=START&end=END` вернет данные в формате JSON с массивом записей следующего вида:

* `visit_id` - id посетителя
* `platform` - платформа с которой был заход на сайт: `web`, `ios`, `android`, `bot`
* `user_agent` - User-Agent посещения
* `datetime` - дата посещения сайта

К примеру:

```text
GET https://data-charts-api.hexlet.app/visits?begin=2022-06-01&end=2023-06-01
```

```json
[
    {
        "datetime": "Wed, 01 Mar 2023 13:29:22 GMT",
        "platform": "web",
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9",
        "visit_id": "1de9ea66-70d3-4a1f-8735-df5ef7697fb9"
    },
    {
        "datetime": "Wed, 01 Mar 2023 16:44:28 GMT",
        "platform": "web",
        "user_agent": "Mozilla/5.0 (X11; CrOS x86_64 8172.45.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.64 Safari/537.36",
        "visit_id": "f149f542-e935-4870-9734-6b4501eaf614"
    }
]
```

Запрос по пути `/registrations?begin=START&end=END` вернет данные в формате JSON с массивом записей следующего вида:

* `user_id` - id зарегистрированного пользователя
* `email` - почта пользователя
* `platform` - платформа с которой была регистрация: `web`, `ios`, `android`
* `registration_type` - тип регистрации: `google`, `apple`, `email`, `yandex`
* `datetime` - дата регистрации на сайте

Например:

```text
GET https://data-charts-api.hexlet.app/registrations?begin=2022-06-01&end=2023-06-02
```

```json
[
    {
        "datetime": "Wed, 01 Mar 2023 00:25:39 GMT",
        "email": "joseph95@example.org",
        "registration_type": "google",
        "platform": "web",
        "user_id": "8838849"
    },
    {
        "datetime": "Wed, 01 Mar 2023 14:53:01 GMT",
        "email": "janetsuarez@example.net",
        "registration_type": "yandex",
        "platform": "web",
        "user_id": "8741065"
    }
]
```

### Ссылки

* [requests](https://requests.readthedocs.io/en/latest/) - библиотека для запросов по сети

### Задачи

* Запросите данные по API за период `2023-03-01 -> 2023-09-01`
* Сохраните ваш ноутбук в репозитории
