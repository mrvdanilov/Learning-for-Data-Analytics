## Как мы проверяем проекты

Проекты проходят автоматическую проверку. Тесты проверяют наличие файлов и их структуру. Статус проверки вы можете увидеть в репозитории GitHub. Вывод тестов расположен во вкладке *Actions* (см. workflow hexlet-check) в вашем репозитории.

Подробнее об автоматической проверке можно почитать [здесь](https://help.hexlet.io/ru/articles/111530-avtoproverka-proektov).

Автоматическая проверка следующие этапы:

* Проверку наличия файлов
* Проверку проверку кода стилистике и логике
* Проверку наличия презентации

## Требования к проекту

Проверьте свой код по пунктам указанным ниже. Если необходимо, внесите исправления в проект:

1. Репозиторий содержит Jupyter Notebook `charts_project.ipynb` со всеми расчетами
2. Notebook работает с переменными окружения для выполнения запросов
3. Notebook читает файл `ads.csv` из директории проекта
4. Notebook сохраняет в текущую директорию JSON файлы с именами `conversion.json` и `ads.json`
5. Notebook сохраняет в директорию `charts` графики (имена могут быть любыми)
6. Презентация заполнена и лежит в формате PDF
7. Графики в презентации содержат числовые подписи для удобного анализа
8. Презентация содержит выводы аналитика

## Полезное

* [Совершенный код: Проектирование функций](https://ru.hexlet.io/blog/posts/sovershennyy-kod-proektirovanie-funktsiy)
* [Нисходящее и восходящее проектирование](https://ru.hexlet.io/blog/posts/sovershennyy-kod-nishodyaschee-i-voshodyaschee-proektirovanie)
* [Плохие и Хорошие практики при проектировании параметров функций](https://ru.hexlet.io/blog/posts/sovershennyy-kod-plohie-i-horoshie-praktiki-pri-proektirovanii-parametrov-funktsiy)
* [Злые однострочники](https://ru.hexlet.io/blog/posts/sovershennyy-kod-zlye-odnostrochniki)
* [Именование](https://ru.hexlet.io/blog/posts/naming-in-programming)
