/* eslint no-param-reassign: ["error", { "props": false }] */
// eslint-disable-next-line
const NodeEnvironment = require('jest-environment-node');

class CustomEnvironment extends NodeEnvironment {
  // NOTE: Implementation of skipping tests after failure
  // when using jest-circus runner
  async handleTestEvent(event) {
    if (event.name === 'test_done' && event.test.errors.length > 0) {
      this.failedTest = true;
    } else if (this.failedTest && event.name === 'test_start') {
      event.test.mode = 'skip';
    }
  }
}

module.exports = CustomEnvironment;
