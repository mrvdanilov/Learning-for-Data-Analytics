import React from 'react';
import ReactDOM from 'react-dom/client';
import {
  Admin,
  Resource,
  Layout
} from 'react-admin';
import axios from 'axios';

import List from './list';
import renderChart from './chart';
import parse from './parser';
import getDataProvider from './dataProvider';

const MyLayout = (props) => <Layout
    {...props}
    appBar={() => {}}
    sidebar={() => {}}
    menu={() => {}}
/>;

const renderList = (data) => {
  const dataProvider = getDataProvider(data);

  ReactDOM.createRoot(document.getElementById('table')).render(
    <React.StrictMode>
      <Admin dataProvider={dataProvider} layout={MyLayout}>
        <Resource name="source" list={List} />
      </Admin>
    </React.StrictMode>
  );
};

export default () => {
  let chart;
  const container = document.getElementById('app');
  const button = document.getElementById('start');
  const buttonContentSource = button.innerHTML;
  const handler = async (event) => {
    document.querySelector('.alert')?.remove();
    button.setAttribute('disabled', 'disabled');
    button.innerHTML = `
      <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
      Загрузка...`;

    try {
      const { data: images } = await axios.post('/run');

      const imagesContainer = document.getElementById('images');
      imagesContainer.innerHTML = '';
  
      images.forEach((chartFileName) => {
        const img = document.createElement('img');
        img.src = `/file/${chartFileName}`;
        imagesContainer.appendChild(img);
      });

      const { data } = await axios.get('/result');

      const chartsData = parse(data);

      const labels = chartsData.visits.map((item) => `${item.date} Platform: ${item.platform}`);

      const datasets = [
        {
          type: 'bar',
          label: 'Посещения',
          data: chartsData.visits.map((item) => item.count),
        },
        {
          type: 'bar',
          label: 'Регистрации',
          data: chartsData.regs.map((item) => item.count),
        }
      ];

      const chartContainer = document.getElementById('chart');
      chartContainer.innerHTML = '';

      renderList(chartsData);

      if (chart) {
        chart.destroy();
      }

      chart = renderChart(chartContainer, labels, datasets);
    } catch (e) {
      console.log(e);
      const alert = document.createElement('div');
      alert.className = 'alert alert-danger';
      alert.setAttribute('role', 'alert');
      alert.textContent = e.response?.data || e.toString();
      container.append(alert);
    }

    button.innerHTML = buttonContentSource;
    button.removeAttribute('disabled');
  };

  button?.addEventListener('click', handler);
  renderList({
    visits: [],
    regs: [],  
  });
};
