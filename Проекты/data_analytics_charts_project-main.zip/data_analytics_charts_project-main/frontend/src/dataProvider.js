import _ from 'lodash';

import { platforms, types } from './utils';

const getDataProvider = (data) => {
  const dataProvider = {
    // get a list of records based on sort, filter, and pagination
    getList: (resource, params) => {
      const source = _.cloneDeep(data);
      let currentData = [];
      
      if (params.filter.types) {
        const currentType = types.find((item) => item.id === params.filter.types);
        currentData = source[currentType.type];
      } else {
        currentData = types.reduce((acc, item) => ([...acc, ...source[item.type]]), []);
      }

      if (params.filter.platform) {
        const currentPlatform = platforms.find((item) => item.id === params.filter.platform);
        currentData = currentData.filter((item) => item.platform === currentPlatform.name);
      }

      if (params.sort) {
        currentData.sort((a, b) => {
          if (params.sort.order === 'DESC') {
            return a[params.sort.field] > b[params.sort.field] ? 1 : -1;
          }
          return a[params.sort.field] < b[params.sort.field] ? 1 : -1;
        });
      }

      const pagesCount = currentData.length / params.pagination.perPage;
      const chunked = _.chunk(currentData, params.pagination.perPage);
      const result = {
        data: chunked[params.pagination.page - 1],
        total: currentData.length,
        pageInfo: {
          hasNextPage: params.pagination.page < pagesCount,
          hasPreviousPage: params.pagination.page > 0,
        },
      };
      return Promise.resolve(result);
    },
    // get a single record by id
    getOne:     (resource, params) => Promise.resolve(data[resource][0]), 
    // get a list of records based on an array of ids
    getMany:    (resource, params) => Promise.resolve(data[resource]), 
    // get the records referenced to another record, e.g. comments for a post
    getManyReference: (resource, params) => Promise.resolve(data[resource]), 
    // create a record
    create:     (resource, params) => Promise.resolve(null), 
    // update a record based on a patch
    update:     (resource, params) => Promise.resolve(null), 
    // update a list of records based on an array of ids and a common patch
    updateMany: (resource, params) => Promise.resolve(null), 
    // delete a record by id
    delete:     (resource, params) => Promise.resolve(null), 
    // delete a list of records based on an array of ids
    deleteMany: (resource, params) => Promise.resolve(null), 
  };

  return dataProvider;
};

export default getDataProvider;
