import {
  List,
  Datagrid,
  TextField,
  SelectInput,
} from 'react-admin';

import { platforms, types } from './utils';

const filters = [
  <SelectInput source="types" choices={types} alwaysOn />,
  <SelectInput source="platform" choices={platforms} alwaysOn />,
];

const Table = () => (
  <List actions={null} filters={filters}>
    <Datagrid bulkActionButtons={false}>
      <TextField source="title" />
      <TextField source="date" />
      <TextField source="platform" />
      <TextField source="count" />
    </Datagrid>
  </List>
);

export default Table;
