import path from 'node:path';
import fastify from 'fastify';
import fastifyStatic from '@fastify/static';
import { spawn } from 'child_process';
import fs from 'fs';

import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const scriptPath = process.env.SCRIPT_PATH || './';
const port = 5001;
const chartsImagesPath = 'charts';

const setUpStaticAssets = (app) => {
  const pathPublic = path.join(__dirname, '..', 'dist');
  app.register(fastifyStatic, {
    root: pathPublic,
  });
};

const run = async () => {
  const app = fastify();

  setUpStaticAssets(app);

  app.post('/run', (req, res) => {
    const pyProg = spawn('poetry', ['run', 'main']);

    pyProg.stdout.on('data', () => {
      const files = fs.readdirSync(chartsImagesPath);
      res.send(files);
    });

    pyProg.stderr.on('data', (data) => {
      console.log(data.toString());
      res.status(500).send(data);
    });
  });

  app.get('/file/:name', (req, res) => {
    const { name } = req.params;
    const file = fs.readFileSync(`charts/${name}`);
    res.header('Content-Type', 'image/png')
    return res.send(file)
  });

  app.get('/result', (req, res) => {
    const file = fs.readFileSync(path.resolve(scriptPath, 'conversion.json'), 'utf8');
    res.header('Content-Type', 'application/json');
    return res.send(file);
  });

  console.log(`Open: http://localhost:${port}`)
  app.listen({ port });
};

export default run;
