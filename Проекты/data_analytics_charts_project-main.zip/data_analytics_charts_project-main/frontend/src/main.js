import './style.css';
import app from './app';

app();
