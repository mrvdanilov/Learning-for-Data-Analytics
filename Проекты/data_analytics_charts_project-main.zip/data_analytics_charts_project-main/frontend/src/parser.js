import _ from 'lodash';

const parse = (sourceData) => {
  const items = Object.keys(sourceData['date_group']).map((id) => {
    const dateTime = new Date(sourceData['date_group'][id]);
    const item = {
      date: `${dateTime.getFullYear()}-${dateTime.getDate()}-${dateTime.getMonth() + 1}`,
      platform: sourceData['platform'][id],
      visits: sourceData['visits'][id],
      registrations: sourceData['registrations'][id],
      conversion: sourceData['conversion'][id],
    };
    return item;
  });
  return items;
};

export default (sourceData) => {
  const parsedData = parse(sourceData);
  const visits = parsedData.map((item) => ({
    id: _.uniqueId(),
    title: 'Посещение',
    count: item.visits,
    platform: item.platform,
    date: item.date,
  }));

  const regs = parsedData.map((item) => ({
    id: _.uniqueId(),
    title: 'Регистрация',
    count: item.registrations,
    platform: item.platform,
    date: item.date,
  }));

  return {
    visits,
    regs,
  };
};
