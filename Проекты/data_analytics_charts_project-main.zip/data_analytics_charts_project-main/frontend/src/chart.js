import Chart from 'chart.js/auto';

export default (ctx, labels, datasets) => {
  const chart = new Chart(ctx, {
    data: {
      labels,
      datasets,
    },
  });

  return chart;
};
