const CSVToJSON = (data, delimiter = ',') => {
  const titles = data.slice(0, data.indexOf('\n')).split(delimiter);
  return data
    .slice(data.indexOf('\n') + 1)
    .split('\n')
    .map((v) => {
      const values = v.split(delimiter);
      return titles.reduce(
        (obj, title, index) => ((obj[title] = values[index]), obj),
        {}
      );
    });
};

const platforms = [
  {
    id: 1,
    name: 'ios',
  },
  {
    id: 2,
    name: 'android',
  },
  {
    id: 3,
    name: 'web',
  },
];

const types = [
  {
    id: 1,
    name: 'Регистрации',
    type: 'regs',
  },
  {
    id: 2,
    name: 'Посещения',
    type: 'visits',
  },
];

export {
  CSVToJSON,
  platforms,
  types,
};
