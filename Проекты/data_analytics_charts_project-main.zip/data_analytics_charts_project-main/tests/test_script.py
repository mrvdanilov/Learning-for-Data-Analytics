import subprocess
from pathlib import Path
import json
import pytest


def run_app(dir):
    args = ['poetry', 'run', 'jupyter', 'execute',  './charts_project.ipynb']
    return subprocess.run(args, cwd=dir, capture_output=True, text=True)


def get_fixture_path(file_name):
    current_dir = Path(__file__).absolute().parent
    return current_dir / 'fixtures' / file_name


def read(file_path, mode='r'):
    with open(file_path, mode) as f:
        result = f.read()
    return result


def get_fixture_data(file_name):
    return read(get_fixture_path(file_name))


@pytest.fixture(scope='session')
def tmp_dir():
    p = Path.cwd()
    d = p / 'tmp' / 'artifacts'
    return d


def test_script(tmp_dir):
    p = run_app(tmp_dir)
    assert p.returncode == 0


def test_has_charts(tmp_dir):
    run_app(tmp_dir)
    charts_dir = tmp_dir / 'charts'
    assert list(charts_dir.iterdir()) != []


def test_out_json(tmp_dir):
    run_app(tmp_dir)
    out = open(tmp_dir / 'conversion.json').read()
    assert json.loads(get_fixture_data('conversion.json')) == json.loads(out)
