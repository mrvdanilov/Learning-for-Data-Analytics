COPY visits FROM '/scripts/data/visits.csv' DELIMITER ',' CSV;
