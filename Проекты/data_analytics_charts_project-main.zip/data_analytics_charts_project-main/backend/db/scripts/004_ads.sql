COPY ads FROM '/scripts/data/ads.csv' DELIMITER ',' CSV;
