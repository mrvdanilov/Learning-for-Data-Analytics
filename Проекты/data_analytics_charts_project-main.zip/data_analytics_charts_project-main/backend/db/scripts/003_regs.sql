COPY registrations FROM '/scripts/data/regs.csv' DELIMITER ',' CSV;
