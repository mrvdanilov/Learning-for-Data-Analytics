import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { expect, test } from '@jest/globals';
import { parse } from 'csv-parse';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const getFixturePath = (filename) => path.join(__dirname, '..', '__fixtures__', filename);
const getCodeFilePath = (filename) => path.join(__dirname, '..', 'code', filename);

const readCsv = (filePath) => new Promise((resolve) => {
  fs.readFile(filePath, (_err, data) => {
    parse(data, (_, rows) => {
      const result = [];
      rows.forEach((row) => {
        result.push(row);
      });
      resolve(result);
    });
  });
});

// Проверяем, что файлы есть и они не пустые
// Например, есть ли файл с презентацией

const files = [
  'aggregate_last_paid_click.csv',
  'aggregate_last_paid_click.sql',
  'last_paid_click.csv',
  'last_paid_click.sql',
  'presentation.pdf',
];

test.each(files)('validate that file %s exists', (checkedFile) => {
  const filepath = getCodeFilePath(checkedFile);

  expect(fs.existsSync(filepath)).toBe(true);

  const { size } = fs.statSync(filepath);
  expect(size).toBeGreaterThan(0);
});

// TODO: add tests

const testList = [
  'aggregate_last_paid_click.csv',
  'last_paid_click.csv',
];

test.each(testList)('validate file: %s', async (testingArtefact) => {
  const rightAnswers = await readCsv(getFixturePath(testingArtefact));
  const userAnswers = await readCsv(getCodeFilePath(testingArtefact));
  expect(rightAnswers).toEqual(userAnswers);
});
