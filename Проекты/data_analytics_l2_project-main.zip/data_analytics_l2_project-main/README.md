# Data analytics project

## Setup

```bash
make compose-setup
```

## Run tests

```bash
make compose-test
```

## Check lint

```bash
make compose-lint
```
