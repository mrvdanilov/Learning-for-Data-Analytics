-- агрегированная таблица без utm_campaign
--сюда можно вставить запрос с любой атрибуции

with attribution as (
    with visitors_with_leads as (
        select
            s.visitor_id,
            s.datetime,
            s.source as utm_source,
            s.medium as utm_medium,
            s.campaign as utm_campaign,
            l.created_at,
            l.amount,
            l.closing_reason,
            l.status_id,
            row_number() over (
                partition by s.visitor_id order by s.datetime desc
            ) as rn
        from sessions as s
        left join leads as l
            on l.visitor_id = s.visitor_id and l.created_at >= s.datetime
    )

    select *
    from visitors_with_leads
    where rn = 1
)

select
    utm_source,
    utm_medium,
    date(visit_date) as created_at,
    count(visitor_id) as visitors_count,
    count(case when created_at is not null then visitor_id end) as leads_count,
    count(case when status_id = 142 then visitor_id end) as purchases_count,
    sum(case when status_id = 142 then amount end) as revenue
from attribution
group by 1, 2, 3
