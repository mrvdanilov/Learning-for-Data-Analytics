-- сюда можно вставить запрос с любой атрибуции с attribution.sql.
-- сейчас здесь first_click

with attribution as (
    with visitors_with_leads as (
        select
            l.s.visitor_id,
            l.datetime,
            l.medium as utm_medium,
            l.campaign as utm_campaign,
            l.created_at,
            l.amount,
            l.closing_reason,
            l.status_id,
            case
                when s.medium = 'referral' then 'website' else s.source
            end as utm_source,
            row_number() over (
                partition by s.visitor_id order by s.datetime desc
            ) as rn
        from sessions as s
        left join leads as l
            on
                l.visitor_id = s.visitor_id
                and l.created_at >= s.datetime
    )

    select *
    from visitors_with_leads
    where rn = 1
)

select
    utm_source,
    utm_medium,
    percentile_disc(0.90) within group (
        order by date_part('day', created_at - datetime)
    ) as days_to_lead
from attribution
group by 1, 2
