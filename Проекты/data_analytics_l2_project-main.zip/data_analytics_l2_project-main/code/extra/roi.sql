-- выше запрос с таблицей агрегации

-- расчет roi и прочих метрик по utm_source
select
    utm_source,
    sum(total_cost) as sum_costs,
    sum(visitors_count) as sum_visitors,
    round(sum(total_cost) / sum(leads_count), 2) as cpl,
    round(sum(total_cost) / sum(purchases_count), 2) as cppu,
    round(sum(total_cost) / sum(visitors_count), 2) as cpu,
    round((sum(total_cost) - sum(revenue)) / sum(total_cost) * 100, 2) as roi
from agregation
group by utm_source
having utm_source in ('vk', 'yandex');

-- расчет roi и прочих метрик по source и campaign
select
    utm_source,
    utm_campaign,
    sum(total_cost) as sum_costs,
    sum(visitors_count) as sum_visitors,
    round(sum(total_cost) / sum(leads_count), 2) as cpl,
    round(sum(total_cost) / sum(purchases_count), 2) as cppu,
    round(sum(total_cost) / sum(visitors_count), 2) as cpu,
    round((sum(total_cost) - sum(revenue)) / sum(total_cost) * 100, 2) as roi
from agregation
group by utm_source, utm_campaign
having
    utm_source in ('vk', 'yandex')
    and sum(leads_count) != 0
    and sum(purchases_count) != 0
    and sum(visitors_count) != 0;
