## Подготовка к работе с данными

Вам был предоставлен доступ к основной базе данных образовательной школы. На этом шаге вы подключитесь к ней и сможете читать из нее данные.

### Описание базы данных

![dbeaver test connection](assets/test_connection.png)

*sessions* — Сессии пользователей. Активность пользователя на платформе

Описание:

* visitor_id — Уникальный id посетителя
* visit_date — Дата и время сессии
* landing_page — Посадочная страница
* source — utm_source (источник перехода). Для рекламных переходов (yandex, vk) можно найти затраты в таблицах *ya_ads* и *vk_ads* связав таблицы по *source*, *medium*, *campaign*, *content*
* medium — utm_medium (Тип рекламной кампании)
* campaign — utm_campaign (Название рекламной кампании)
* content — utm_content (Название сегмента рекламного объявления)

*leads* — таблица лидов. Лид — пользователь, который заинтересовался обучением и оставил свои контакты

Описание:

* visitor_id — Уникальный id посетителя. Связана с полем *sessions.visitors_id*
* lead_id — Уникальный id лида
* amount — Сумма сделки
* created_at — Дата и время создания сделки
* closing_reason — Причина закрытия сделки
* learning_format — Формат обучения
* status_id — id статуса сделки в CRM

*vk_ads* — Объявления в VK.

Описание:

* ad_id — id объявления
* ad_name — Название объявления
* campaign_id — id рекламной кампании
* campaign_name — Имя кампании в рекламном кабинете
* campaign_date — Дата расхода
* daily_spent — Расход на рекламную компанию
* utm_source — Источник перехода
* utm_medium — Тип рекламной кампании
* utm_campaign — Название рекламной кампании
* utm_content — Название сегмента рекламного объявления

*ya_ads* — Объявления в Yandex.

Описание:

* ad_id — id объявления
* campaign_id — id рекламной кампании
* campaign_name — Имя кампании в рекламном кабинете
* utm_source — Источник перехода
* utm_medium — Тип рекламной кампании
* utm_campaign — Название рекламной кампании
* utm_content — Название сегмента рекламного объявления
* campaign_date — Дата расхода
* daily_spent — Расход на рекламную компанию

### Ссылки

* [DBeaver](https://dbeaver.io/download/) — инструмент для работы с базами данных
* [Инструкция по подключению к базе данных](https://dbeaver.com/docs/wiki/Create-Connection/)

### Задачи

* Скачайте [DBeaver](https://dbeaver.io/download/) — программу для работы с базой данных. Выберите `PostgreSQL` и по [инструкции](https://dbeaver.com/docs/wiki/Create-Connection/) создайте новое подключение. Используйте следующие данные:

  * Host: 65.108.223.44
  * Database: marketingdb
  * Username: student
  * Password: student
  * Port: 5432

  Нажмите *Test connection* и проверьте, что соединение сработало:

  ![dbeaver test connection](assets/test_connection.png)

* Подключитесь к базе данных и проверьте, что запросы выполняются.
