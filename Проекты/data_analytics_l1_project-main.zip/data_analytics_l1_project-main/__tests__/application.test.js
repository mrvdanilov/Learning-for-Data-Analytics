import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { expect, test } from '@jest/globals';
import { parse } from 'csv-parse';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const getFixturePath = (filename) => path.join(__dirname, '..', '__fixtures__', filename);
const getCodeFilePath = (filename) => path.join(__dirname, '..', 'code', filename);

const readCsv = (filePath) => new Promise((resolve) => {
  fs.readFile(filePath, (_err, data) => {
    parse(data, (_, rows) => {
      const result = [];
      rows.forEach((row) => {
        result.push(row);
      });
      resolve(result);
    });
  });
});

const testList = [
  ['top_10_popular_products.csv', 'top_10_popular_products_fixture.csv'],
  ['top_10_profitable_products.csv', 'top_10_profitable_products_fixture.csv'],
  ['top_10_profitable_products.csv', 'top_10_profitable_products_fixture.csv'],
  ['customers_count.csv', 'customers_count_fixture.csv'],
  ['top_10_total_income.csv', 'top_10_total_income_fixture.csv'],
  ['lowest_average_income.csv', 'lowest_average_income_fixture.csv'],
  ['day_of_the_week_income.csv', 'day_of_the_week_income_fixture.csv'],
  ['age_groups.csv', 'age_groups_fixture.csv'],
  ['customers_by_month.csv', 'customers_by_month_fixture.csv'],
  ['special_offer.csv', 'special_offer_fixture.csv'],
];

test.each(testList)('validate file: %s', async (testingArtefact, fixtureName) => {
  const rightAnswers = await readCsv(getFixturePath(fixtureName));
  const userAnswers = await readCsv(getCodeFilePath(testingArtefact));
  expect(rightAnswers).toEqual(userAnswers);
});

// Проверяем, что файлы есть и они не пустые
// Например, есть ли файл с презентацией

const files = [
  'queries.sql',
  'presentation.pdf',
];

test.each(files)('validate that file %s exists', (checkedFile) => {
  const filepath = getCodeFilePath(checkedFile);

  expect(fs.existsSync(filepath)).toBe(true);

  const { size } = fs.statSync(filepath);
  expect(size).toBeGreaterThan(0);
});
