## Подготовка к работе с данными

Перед тем, как работать с полным набором данных и всеми таблицами, поработаем с одной таблицей. Для этого шага подготовлены [данные о продажах](https://docs.google.com/spreadsheets/d/1Y_gzrFfOAJfTZo2u-PfU4selSic11dqM50bS3RlLA8M/copy?usp=sharing), их необходимо скопировать. Вся работа ведется в вашем пространстве Google Sheets.

Описание колонок:

* SalesID — ID продажи
* SalesPersonID — ID продавца
* CustomerID — ID покупателя
* ProductID — ID проданного товара
* Quantity — количество проданного товара

### Ссылки

* [Данные о продажах](https://docs.google.com/spreadsheets/d/1Y_gzrFfOAJfTZo2u-PfU4selSic11dqM50bS3RlLA8M/copy?usp=sharing) — необходимые данные для текущего шага

### Задачи

1. Скопируйте к данные в Google Sheets
2. Создайте таблицу с итогами продаж
3. Запишите в ней товары, которые продавались больше всего и в каком количестве
