## Дашборды

Результаты проведенного исследования продавцов и покупателей следует представить в виде дашборда, который наилучшим образом отразит полученные результаты.

![Dashbord example](assets/dashbord_example.png)

### Задачи

1. Загрузите следующие csv-файлы в [Preset](https://preset.io/):
   * top_10_total_income.csv
   * lowest_average_income.csv
   * day_of_the_week_income.csv
   * age_groups.csv
   * customers_by_month.csv
   * special_offer.csv
2. Составьте дашборд по имеющимся данным
